package chat;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

//继承JFrame，此时，该类可以被称为窗口类。
//1.定义JFrame窗体中的组件
//2.在构造方法中初始化窗体的组件
//3.网络变成完成数据的传输（TCP，UDP）协议
//4.实现‘发送’按钮的监听点击事件
//5.实现'回车键'发送内容功能
public class ServerChatMain extends  JFrame implements ActionListener, KeyListener {
    public static void main(String[] args)
    {
        //调用构造方法
        new ServerChatMain();
    }
    //属性
    //文本域
    private JTextArea jta;
    //滚动条
    private JScrollPane jsp;
    //面板
    private JPanel jp;
    //文本框
    private  JTextField jtf;
    //按钮
    private JButton jb;
    //输出流
    private BufferedWriter bw=null;
    //服务端的端口号
    private static int serverPort;
    //使用static 静态代码块读取外部配置文件
    //特点1： 在类加载的时候，自动执行
    //特点2： 一个类只会被加载一次，因此静态代码在程序中仅会被执行一次
    static
    {
        Properties prop= new Properties();

        try {
            //加载
            prop.load(new FileReader("chat.properties"));
            //给属性赋值
            serverPort =Integer.parseInt(prop.getProperty("serverPort"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //构造方法
    public ServerChatMain()
    {
        //初始化组件
        jta =new JTextArea();
        //注意：需要将文本域添加到滚动条中，
        //设置文本域不可编辑
        jta.setEditable(false);
        jsp =new JScrollPane(jta);
        //面板
        jp= new JPanel();
        jtf = new JTextField(10);
        jb =new JButton("发送");
        //注意：需要将文本框与按钮添加到面板中：
        jp.add(jtf);
        jp.add(jb);
        //注意：需要将滚动条和面板全部添加到窗体中
        this.add(jsp, BorderLayout.CENTER);
        this.add(jp,BorderLayout.SOUTH);
        //需要设置 标题，大小，位置，关闭，是否可见
        this.setTitle("QQ聊天 服务器");
        this.setSize(300,300);
        this.setLocation(300,300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        /*******************************TCP 服务端start *********************************/



        //给发送按钮绑定一个监听点击事件
        jb.addActionListener(this);
        //给文本框绑定一个监听点击事件
        jtf.addKeyListener(this);
        try {
            //1.创建一个服务端的套接字
            ServerSocket serverSocket= new ServerSocket(serverPort);

            //2.等待客户端的连接
            Socket socket= serverSocket.accept();

            //3.获取socket 通道的输入流(输入流实现读取数据，如何读取？？？ 一行一行读取)
            BufferedReader br =new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //4.获取socket 通道的输出流(实现写出数据，也是写一行换一行，刷新)
            //问题： 什么时候需要写出数据？？？ 当用户点击‘发送’按钮的时候菜需要写出数据
            bw=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

            //循环读取数据，并拼接到文本域中
            String line=null;
            while ((line=br.readLine())!=null)
            {
                //江都区的数据拼接到文本域中显示
                jta.append(line+ System.lineSeparator());

            }


            //5.关闭socket 通道
            serverSocket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }


        /*******************************TCP 服务端end   *********************************/

    }


    @Override
    public void actionPerformed(ActionEvent e) {
//        System.out.println("发送按钮被点击了");

        sendDataToSocket();
    }
    //行为
    @Override

    public void keyPressed(KeyEvent e) {

        //回车键
        if(e.getKeyCode()==KeyEvent.VK_ENTER)
        {

            sendDataToSocket();
        }

    }
    @Override
    public void keyTyped(KeyEvent e) {

    }
    @Override
    public void keyReleased(KeyEvent e) {

    }
    //定义一个方法，实现将数据发送到socket 通道中
    private void sendDataToSocket()
    {

        //发送数据到socket 通道中
        String text=jtf.getText();
        //2.拼接需要发送的数据内容
        text="服务端对客户端说："+ text;
        //3.对自己也要显示
        jta.append(text+ System.lineSeparator());
        //4.发送
        try {
            bw.write(text);
            bw.newLine();
            bw.flush();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        //5.清空文本框
        jtf.setText("");
    }

}
