package chat;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.*;
import java.net.Socket;
import java.util.Properties;

public class ClientChatMain extends JFrame implements ActionListener, KeyListener {
    public static void main(String[] args)
    {
        //调用构造方法
        new ClientChatMain();
    }
    //属性
    //文本域
    private JTextArea jta;
    //滚动条
    private JScrollPane jsp;
    //面板
    private JPanel jp;
    //文本框
    private  JTextField jtf;
    //按钮
    private JButton jb;
    //输出流
    private BufferedWriter bw=null;
    //客户端的IP
    private static String clientIp;
    //客户端的端口号
    private static int clientPort;
    static {
        Properties prop=new Properties();
        try {
            prop.load(new FileReader("chat.properties"));
            clientIp=prop.getProperty("clientIp");
            clientPort=Integer.parseInt(prop.getProperty("clientPort"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //构造方法
    public ClientChatMain()
    {
        //初始化组件
        jta =new JTextArea();
        //注意：需要将文本域添加到滚动条中，
        //设置文本域不可编辑
        jta.setEditable(false);
        jsp =new JScrollPane(jta);
        //面板
        jp= new JPanel();
        jtf = new JTextField(10);
        jb =new JButton("发送");
        //注意：需要将文本框与按钮添加到面板中：
        jp.add(jtf);
        jp.add(jb);
        //注意：需要将滚动条和面板全部添加到窗体中
        this.add(jsp, BorderLayout.CENTER);
        this.add(jp,BorderLayout.SOUTH);
        //需要设置 标题，大小，位置，关闭，是否可见
        this.setTitle("QQ聊天 客户端");
        this.setSize(300,300);
        this.setLocation(600,300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        /*******************************TCP 客户端start *********************************/

        //给发送按钮帮点一个监听点击事件
        jb.addActionListener(this);
        jtf.addKeyListener(this);

        try {
            //1.创建一个客户端的套接字（尝试连接）
            Socket socket=new Socket(clientIp,clientPort);

            //2.获取socket 通道的输入流

            BufferedReader br=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            //3.获取socket 通道的输出流
             bw =new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));


            //循环读取数据，并拼接到文本域中
            String line =null;
            while((line= br.readLine())!=null)
            {
                jta.append(line+System.lineSeparator());
            }

            //4.关闭socket 通道
            socket.close();
        }
        catch (IOException e)
        {

        }


        /*******************************TCP 客户端end   *********************************/




    }

    @Override
    public void actionPerformed(ActionEvent e) {

        sendDataToSocket();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==KeyEvent.VK_ENTER)
        {
            sendDataToSocket();
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
    private void sendDataToSocket()
    {

        //发送数据到socket 通道中
        String text=jtf.getText();
        //2.拼接需要发送的数据内容
        text="客户端对服务端说："+ text;
        //3.对自己也要显示
        jta.append(text+ System.lineSeparator());
        //4.发送
        try {
            bw.write(text);
            bw.newLine();
            bw.flush();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        //5.清空文本框
        jtf.setText("");
    }
}
